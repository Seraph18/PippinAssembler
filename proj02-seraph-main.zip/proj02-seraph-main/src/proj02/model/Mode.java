package proj02.model;

public enum Mode {

	NOM,
	IMM,
	DIR,
	IND;

}
